To use, copy the eztwitt directory into your htdocs directory so that xampp can find it.

The main page is titled Page.php

Open a browser and navigate to http://localhost/eztwitt/page.php and then enjoy submitting queries!

Laura Lucaciu and Willis Hand
